import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#faf8f3",
        ink: "#1b1b18",
        line: "#dcd8cc",
        muted: "#6b6a62",
        forest: "#2f5d46",
        rust: "#a4472f",
      },
      fontFamily: { sans: ["var(--font-inter)", "system-ui", "sans-serif"] },
      borderRadius: { DEFAULT: "6px" },
    },
  },
  plugins: [],
};
export default config;
