# Naskah

Better writing. One document at a time.

**Status: Stage 2 (UI + workspace dasar).** Belum ada: ekstraksi PDF, ekspor PDF, AI.
Belum diuji dengan `npm install` / `npm run build` (lihat catatan di pesan pengembang).

## Menjalankan
```bash
npm install
npm run dev        # buka http://localhost:3000
npm run typecheck
npm run lint
npm run build
```
