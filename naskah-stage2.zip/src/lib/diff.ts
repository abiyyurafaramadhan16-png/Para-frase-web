export type DiffOp = { type: "same" | "add" | "del"; text: string };

const MAX_CELLS = 6_000_000;

/** Perbandingan per kata (LCS). Mengembalikan null jika teks terlalu panjang. */
export function diffWords(a: string, b: string): DiffOp[] | null {
  const x = a.split(/(\s+)/).filter(Boolean);
  const y = b.split(/(\s+)/).filter(Boolean);
  const m = x.length;
  const n = y.length;
  if ((m + 1) * (n + 1) > MAX_CELLS) return null;

  const w = n + 1;
  const dp = new Uint32Array((m + 1) * w);
  for (let i = m - 1; i >= 0; i--) {
    for (let j = n - 1; j >= 0; j--) {
      dp[i * w + j] =
        x[i] === y[j]
          ? dp[(i + 1) * w + j + 1] + 1
          : Math.max(dp[(i + 1) * w + j], dp[i * w + j + 1]);
    }
  }

  const ops: DiffOp[] = [];
  const push = (type: DiffOp["type"], text: string) => {
    const last = ops[ops.length - 1];
    if (last && last.type === type) last.text += text;
    else ops.push({ type, text });
  };

  let i = 0;
  let j = 0;
  while (i < m && j < n) {
    if (x[i] === y[j]) {
      push("same", x[i]);
      i++;
      j++;
    } else if (dp[(i + 1) * w + j] >= dp[i * w + j + 1]) {
      push("del", x[i++]);
    } else {
      push("add", y[j++]);
    }
  }
  while (i < m) push("del", x[i++]);
  while (j < n) push("add", y[j++]);
  return ops;
}
