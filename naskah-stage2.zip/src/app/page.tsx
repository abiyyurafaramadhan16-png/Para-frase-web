import Workspace from "@/components/Workspace";

export default function Home() {
  return (
    <>
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6">
          <span className="text-[17px] font-semibold tracking-tight">
            Naskah<span className="text-forest">.</span>
          </span>
          <nav className="text-sm text-muted">Dokumen</nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-10">
        <h1 className="text-2xl font-semibold tracking-tight">Your documents.</h1>
        <p className="mt-1 text-sm text-muted">Better writing. One document at a time.</p>
        <div className="mt-6">
          <Workspace />
        </div>
      </main>
    </>
  );
}
