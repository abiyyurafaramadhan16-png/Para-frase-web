"use client";

import { useMemo, useState } from "react";
import { Check, Copy, FileUp, RotateCcw, Sparkles, X } from "lucide-react";
import { countWords, MAX_CHARS } from "@/lib/text";
import { diffWords } from "@/lib/diff";
import {
  DEFAULT_SETTINGS,
  INTENSITIES,
  STYLES,
  type Settings,
} from "@/lib/settings";

type Tab = "original" | "revised" | "diff";

const btn =
  "inline-flex items-center gap-1.5 rounded border border-line px-3 py-1.5 text-sm hover:bg-black/[0.03] disabled:cursor-not-allowed disabled:opacity-50";
const area =
  "w-full min-h-[50vh] lg:min-h-[60vh] rounded border border-line bg-white/60 p-3 text-[15px] leading-relaxed focus:border-forest focus:outline-none";

export default function Workspace() {
  const [draft, setDraft] = useState("");
  const [error, setError] = useState("");
  const [original, setOriginal] = useState<string | null>(null);
  const [revised, setRevised] = useState("");
  const [tab, setTab] = useState<Tab>("revised");
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [copied, setCopied] = useState(false);

  const diff = useMemo(
    () => (tab === "diff" && original !== null ? diffWords(original, revised) : null),
    [tab, original, revised],
  );

  function open() {
    if (!draft.trim()) return setError("Teks masih kosong. Tempel teks terlebih dahulu.");
    if (draft.length > MAX_CHARS)
      return setError(`Teks terlalu panjang (maksimal ${MAX_CHARS.toLocaleString("id-ID")} karakter).`);
    setError("");
    setOriginal(draft);
    setRevised(draft);
    setTab("revised");
  }

  function close() {
    if (original !== null && revised !== original && !window.confirm("Hasil edit akan dibuang. Lanjutkan?")) return;
    setOriginal(null);
    setRevised("");
    setDraft("");
  }

  function reset() {
    if (original === null || revised === original) return;
    if (window.confirm("Kembalikan hasil ke teks asli?")) setRevised(original);
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(revised);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      setError("Gagal menyalin. Pilih teks lalu salin manual.");
    }
  }

  const set = <K extends keyof Settings>(k: K, v: Settings[K]) =>
    setSettings((s) => ({ ...s, [k]: v }));

  // ---------- Tampilan input ----------
  if (original === null) {
    return (
      <section className="max-w-2xl">
        <button
          type="button"
          disabled
          className="flex w-full items-center gap-3 rounded border border-dashed border-line px-4 py-4 text-left text-sm text-muted disabled:cursor-not-allowed"
        >
          <FileUp size={18} aria-hidden />
          <span>
            Unggah PDF
            <span className="block text-xs">Belum tersedia. Ekstraksi PDF dibuat di Stage 3.</span>
          </span>
        </button>

        <label htmlFor="paste" className="mt-6 block text-sm font-medium">
          Atau tempel teks
        </label>
        <textarea
          id="paste"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Tempel teks dokumen di sini…"
          className={`${area} mt-2`}
        />
        <div className="mt-2 flex items-center justify-between text-xs text-muted">
          <span>{countWords(draft).toLocaleString("id-ID")} kata</span>
          <span>
            {draft.length.toLocaleString("id-ID")} / {MAX_CHARS.toLocaleString("id-ID")} karakter
          </span>
        </div>
        {error && (
          <p role="alert" className="mt-3 text-sm text-rust">
            {error}
          </p>
        )}
        <button
          type="button"
          onClick={open}
          className="mt-4 rounded bg-forest px-4 py-2 text-sm font-medium text-white hover:opacity-90"
        >
          Buka di editor
        </button>
      </section>
    );
  }

  // ---------- Tampilan editor ----------
  const tabs: { id: Tab; label: string; cls: string }[] = [
    { id: "original", label: "Asli", cls: "lg:hidden" },
    { id: "revised", label: "Hasil", cls: "lg:hidden" },
    { id: "diff", label: "Perbandingan", cls: "" },
  ];
  const showOriginal = tab === "original" ? "block" : "hidden lg:block";
  const showRevised = tab === "revised" ? "block" : "hidden lg:block";

  return (
    <section>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted">
          Asli {countWords(original).toLocaleString("id-ID")} kata · Hasil{" "}
          {countWords(revised).toLocaleString("id-ID")} kata
        </p>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={copy} className={btn}>
            {copied ? <Check size={15} /> : <Copy size={15} />}
            {copied ? "Tersalin" : "Salin hasil"}
          </button>
          <button type="button" onClick={reset} disabled={revised === original} className={btn}>
            <RotateCcw size={15} /> Reset
          </button>
          <button type="button" onClick={close} className={btn}>
            <X size={15} /> Ganti dokumen
          </button>
        </div>
      </div>

      <fieldset className="mt-5 grid gap-4 rounded border border-line p-4 sm:grid-cols-2 lg:grid-cols-4">
        <legend className="px-1 text-xs uppercase tracking-wide text-muted">Pengaturan</legend>
        <label className="text-sm">
          Gaya
          <select
            value={settings.style}
            onChange={(e) => set("style", e.target.value as Settings["style"])}
            className="mt-1 block w-full rounded border border-line bg-white/60 px-2 py-1.5"
          >
            {STYLES.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </label>
        <label className="text-sm">
          Intensitas
          <select
            value={settings.intensity}
            onChange={(e) => set("intensity", e.target.value as Settings["intensity"])}
            className="mt-1 block w-full rounded border border-line bg-white/60 px-2 py-1.5"
          >
            {INTENSITIES.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </label>
        <div className="space-y-1 text-sm sm:col-span-2">
          {(
            [
              ["preserveCitations", "Pertahankan sitasi"],
              ["preserveTerms", "Pertahankan istilah teknis"],
              ["preserveNumbers", "Pertahankan angka dan persamaan"],
            ] as const
          ).map(([k, label]) => (
            <label key={k} className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings[k]}
                onChange={(e) => set(k, e.target.checked)}
                className="accent-forest"
              />
              {label}
            </label>
          ))}
        </div>
      </fieldset>

      <div className="mt-3 flex flex-wrap items-center gap-3 text-sm">
        <button type="button" disabled className={btn}>
          <Sparkles size={15} /> Perbaiki dengan AI
        </button>
        <span className="text-xs text-muted">
          Integrasi AI belum dipasang di versi ini (Stage 4). Sunting dan perbandingan tetap bisa dipakai.
        </span>
      </div>

      <div role="tablist" className="mt-6 flex gap-1 border-b border-line">
        {tabs.map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => setTab(t.id)}
            className={`-mb-px border-b-2 px-3 py-2 text-sm ${t.cls} ${
              tab === t.id ? "border-forest font-medium" : "border-transparent text-muted"
            }`}
          >
            {t.label}
          </button>
        ))}
        <button
          role="tab"
          aria-selected={tab !== "diff"}
          onClick={() => setTab("revised")}
          className={`-mb-px hidden border-b-2 px-3 py-2 text-sm lg:block ${
            tab !== "diff" ? "border-forest font-medium" : "border-transparent text-muted"
          }`}
        >
          Sunting
        </button>
      </div>

      {tab === "diff" ? (
        <div className="mt-4 rounded border border-line bg-white/60 p-3 text-[15px] leading-relaxed">
          {diff === null ? (
            <p className="text-sm text-muted">
              Dokumen terlalu panjang untuk perbandingan per kata di browser. Bandingkan per bagian
              (fitur ini akan ditambahkan).
            </p>
          ) : diff.every((d) => d.type === "same") ? (
            <p className="text-sm text-muted">Belum ada perbedaan antara teks asli dan hasil.</p>
          ) : (
            <p className="whitespace-pre-wrap break-words">
              {diff.map((d, i) =>
                d.type === "same" ? (
                  <span key={i}>{d.text}</span>
                ) : d.type === "add" ? (
                  <span key={i} className="bg-forest/10 text-forest">{d.text}</span>
                ) : (
                  <span key={i} className="bg-rust/10 text-rust line-through">{d.text}</span>
                ),
              )}
            </p>
          )}
        </div>
      ) : (
        <div className="mt-4 grid gap-4 lg:grid-cols-2">
          <div className={showOriginal}>
            <label htmlFor="orig" className="mb-1 hidden text-xs uppercase tracking-wide text-muted lg:block">
              Asli (tidak bisa diubah)
            </label>
            <textarea id="orig" readOnly value={original} className={`${area} bg-black/[0.02]`} />
          </div>
          <div className={showRevised}>
            <label htmlFor="rev" className="mb-1 hidden text-xs uppercase tracking-wide text-muted lg:block">
              Hasil (bisa diedit)
            </label>
            <textarea id="rev" value={revised} onChange={(e) => setRevised(e.target.value)} className={area} />
          </div>
        </div>
      )}

      {error && (
        <p role="alert" className="mt-3 text-sm text-rust">
          {error}
        </p>
      )}
      <p className="mt-4 text-xs text-muted">
        Ekspor PDF belum tersedia (Stage 3). Teks Anda hanya ada di browser ini dan tidak disimpan.
      </p>
    </section>
  );
}
