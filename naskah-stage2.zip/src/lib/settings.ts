export const STYLES = ["Academic", "Professional", "Natural", "Simple"] as const;
export const INTENSITIES = ["Light", "Balanced", "Deep"] as const;

export type Style = (typeof STYLES)[number];
export type Intensity = (typeof INTENSITIES)[number];

export type Settings = {
  style: Style;
  intensity: Intensity;
  preserveCitations: boolean;
  preserveTerms: boolean;
  preserveNumbers: boolean;
};

export const DEFAULT_SETTINGS: Settings = {
  style: "Academic",
  intensity: "Balanced",
  preserveCitations: true,
  preserveTerms: true,
  preserveNumbers: true,
};
